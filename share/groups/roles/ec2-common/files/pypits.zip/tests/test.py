from libspits import SimpleEndpoint
import sys
import json
import libspits.messaging

recv_timeout = 10

if __name__ == '__main__':
    global recv_timeout
    choice = ''
    e = None

    while choice != 'exit':
        try:
            choice = input("Command: ")

            if choice == 'help':
                print("""
    [co|connect] <jobid> <hostaddr> <port> -- Connect to host and perform job handshake 
    [cl|close] -- Close connection
    [ml|metrics-list] -- Query metrics list
    [mv|metrics-values] <metric1> [<metric2>, ...]-- Query the last values for the list of metrics
    
                """)
                continue

            commands = choice.split(' ')
            cmd = commands[0].lower()

            if cmd == 'co' or cmd == 'connect':
                jobid = commands[1].strip()
                hostaddr = commands[2].strip()
                port = int(commands[3].strip())

                e = SimpleEndpoint(hostaddr, port)
                print("Connecting to {}:{}...".format(hostaddr, port))
                e.Open(recv_timeout)
                print("Connected")

                # job handshake!
                print("Performing job handshake with job".format(jobid))
                e.WriteString(jobid)
                if not e.ReadString(recv_timeout) == jobid:
                    e.Close()
                    print("Closed connection to {}:{}".format(hostaddr, port))
                    e = None
                    raise Exception("Invalid job id received!")

                print("OK")

                continue

            elif cmd == 'cl' or cmd == 'close':
                if e:
                    e.Close()
                    print("Closed connection to {}:{}".format(e.address, e.port))
                    e = None
                else:
                    print("Connection already closed!")

                continue

            elif cmd == 'ml' or cmd == 'metrics-list':
                if not e:
                    raise Exception("Connection is not opened!")

                e.WriteInt64(libspits.messaging.msg_cd_query_metrics_list)

                metrics = e.ReadString(recv_timeout)
                metrics = json.loads(metrics)
                print("----METRIC LIST----")
                print(metrics)

                continue

            elif cmd == 'mv' or cmd == 'metrics-values':
                if not e:
                    raise Exception("Connection is not opened!")

                e.WriteInt64(libspits.messaging.msg_cd_query_metrics_last_values)

                send_str = json.dumps(dict(metrics=[{"name": cmd} for cmd in commands[1:]]))
                e.WriteString(send_str)
                metric_values = e.ReadString(recv_timeout)
                metric_values = json.loads(metric_values)
                print("----METRIC VALUES----")
                print(metric_values)

                continue

            elif cmd == 'mh' or cmd == 'metrics-history':
                if not e:
                    raise Exception("Connection is not opened!")

                e.WriteInt64(libspits.messaging.msg_cd_query_metrics_history)

                send_str = json.dumps(dict(metrics=[{"name": cmd.split(':')[0], "size": int(cmd.split(':')[1])} for cmd in commands[1:]]))
                e.WriteString(send_str)
                metric_values = e.ReadString(recv_timeout)
                metric_values = json.loads(metric_values)
                print("----METRIC HISTORY----")
                print(metric_values)

                continue

            else:
                print("Invalid option: {}".format(choice))
                continue

        except Exception as err:
            print("Error: {}".format(err), file=sys.stderr)

        continue

    sys.stdin.flush()